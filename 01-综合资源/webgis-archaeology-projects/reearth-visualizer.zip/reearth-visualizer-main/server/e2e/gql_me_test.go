package e2e

import (
	"context"
	"testing"

	accountsID "github.com/reearth/reearth-accounts/server/pkg/id"
	accountsRole "github.com/reearth/reearth-accounts/server/pkg/role"
	accountsUser "github.com/reearth/reearth-accounts/server/pkg/user"
	accountsWorkspace "github.com/reearth/reearth-accounts/server/pkg/workspace"
	"github.com/reearth/reearth/server/internal/usecase/gateway"
	"github.com/reearth/reearth/server/internal/usecase/repo"
	"github.com/reearth/reearthx/util"
)

const GetMeQuery = `
query GetMe {
  me {
    id
    name
    email
    lang
    theme
    metadata {
      photoURL
    }
    myWorkspace {
      id
      name
      enableToCreatePrivateProject
      __typename
    }
    workspaces {
      id
      name
      personal
      members {
        user {
          id
          name
          email
          __typename
        }
        userId
        role
        __typename
      }
	  enableToCreatePrivateProject
      __typename
    }
    auths
    __typename
  }
}`

// go test -v -run TestMe ./e2e/...

func TestMe(t *testing.T) {
	e := Server(t, baseSeeder)

	requestBody := GraphQLRequest{
		OperationName: "GetMe",
		Query:         GetMeQuery,
		Variables:     map[string]any{},
	}

	res := Request(e, uID.String(), requestBody)

	me := res.Path("$.data.me")

	// ValueDump(me)

	me.Object().HasValue("email", uEmail)
	me.Object().HasValue("id", uID.String())
	me.Object().HasValue("name", uName)

	me.Path("$.myWorkspace.enableToCreatePrivateProject").IsEqual(false)

	me.Path("$.workspaces[0].enableToCreatePrivateProject").IsEqual(false)

}

// go test -v -run TestMeWithPhotoURL ./e2e/...

func TestMeWithPhotoURL(t *testing.T) {
	e := Server(t, seederWithPhotoURL)

	requestBody := GraphQLRequest{
		OperationName: "GetMe",
		Query:         GetMeQuery,
		Variables:     map[string]any{},
	}

	res := Request(e, uID.String(), requestBody)

	me := res.Path("$.data.me")

	// Verify basic user info
	me.Object().HasValue("email", uEmail)
	me.Object().HasValue("id", uID.String())
	me.Object().HasValue("name", uName)

	// Verify photoURL is present
	me.Path("$.metadata.photoURL").IsEqual("https://example.com/photo.jpg")
}

func seederWithPhotoURL(ctx context.Context, r *repo.Container, f gateway.File) error {
	defer util.MockNow(now)()

	// Create metadata with photoURL
	metadata := accountsUser.NewMetadata()
	metadata.SetPhotoURL("https://example.com/photo.jpg")

	// Create user with photoURL in metadata
	u := accountsUser.New().
		ID(uID).
		Workspace(wID).
		Name(uName).
		Email(uEmail).
		Metadata(metadata).
		MustBuild()

	if err := r.User.Save(ctx, u); err != nil {
		return err
	}

	// Create workspace for the user
	w := accountsWorkspace.New().ID(wID).
		Name(uName).
		Personal(false).
		Members(map[accountsID.UserID]accountsWorkspace.Member{u.ID(): {
			Role: accountsRole.RoleOwner,
		}}).
		Metadata(accountsWorkspace.NewMetadata()).
		MustBuild()
	if err := r.Workspace.Save(ctx, w); err != nil {
		return err
	}

	// Run base setup (creates scenes, projects, etc.)
	if err := baseSetup(ctx, r, f); err != nil {
		return err
	}

	// Create additional users and workspaces
	_, err := createUserAndWorkspace(ctx, r, wID2, wAlias2, uID2, uName2, uEmail2)
	if err != nil {
		return err
	}

	u3, err := createUserAndWorkspace(ctx, r, wID3, wAlias3, uID3, uName3, uEmail3)
	if err != nil {
		return err
	}

	// assign user3 to user1's workspace
	if err := JoinMembers(ctx, r, wID, u3, accountsRole.RoleReader, uID); err != nil {
		return err
	}

	return nil
}
