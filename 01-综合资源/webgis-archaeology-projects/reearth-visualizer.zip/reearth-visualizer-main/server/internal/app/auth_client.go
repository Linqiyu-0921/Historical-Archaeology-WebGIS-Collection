package app

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"strings"

	"github.com/labstack/echo/v4"
	"github.com/reearth/reearth/server/internal/adapter"
	"github.com/reearth/reearth/server/internal/usecase"
	"github.com/reearth/reearthx/log"
	"github.com/reearth/reearthx/rerror"

	accountsGqlError "github.com/reearth/reearth-accounts/server/pkg/gqlclient/gqlerror"
	accountsRole "github.com/reearth/reearth-accounts/server/pkg/role"
	accountsUser "github.com/reearth/reearth-accounts/server/pkg/user"
	accountsWorkspace "github.com/reearth/reearth-accounts/server/pkg/workspace"
)

func attachOpMiddlewareMockUser(cfg *ServerConfig) echo.MiddlewareFunc {
	return func(next echo.HandlerFunc) echo.HandlerFunc {
		return func(c echo.Context) error {
			req := c.Request()
			ctx := req.Context()

			ctx = adapter.AttachCurrentHost(ctx, cfg.Config.Host)

			authInfo := adapter.GetAuthInfo(ctx)

			var u *accountsUser.User

			// Check for debug user header first (for e2e tests)
			if cfg.Debug {
				if userID := req.Header.Get("X-Reearth-Debug-User"); userID != "" {
					uid, err := accountsUser.IDFrom(userID)
					if err == nil {
						u, err = cfg.AccountRepos.User.FindByID(ctx, uid)
						if err != nil {
							log.Warnfc(ctx, "auth: debug user not found: %s", userID)
						}
					}
				}
			}

			// Fallback to demo user if debug user not found
			if u == nil {
				mockUser, err := cfg.AccountRepos.User.FindByNameOrEmail(ctx, "Demo User")
				if err != nil && authInfo != nil && authInfo.Sub != "" {
					uId, _ := accountsUser.IDFrom(authInfo.Sub)
					mockUser = accountsUser.New().
						ID(uId).
						Name(authInfo.Name).
						Email(authInfo.Email).
						MustBuild()
				}
				u = mockUser
			}

			if u != nil {
				ctx = adapter.AttachUser(ctx, u)
				log.Debugfc(ctx, "auth: user: id=%s name=%s email=%s", u.ID(), u.Name(), u.Email())

				op, err := generateOperator(ctx, cfg, u)
				if err != nil {
					return err
				}

				ctx = adapter.AttachOperator(ctx, op)
				log.Debugfc(ctx, "auth: op: %#v", op)

			} else {
				log.Errorfc(ctx, "Demo User information not found: %s", req.URL.Path)
			}

			c.SetRequest(req.WithContext(ctx))
			return next(c)
		}
	}
}

func attachOpMiddlewareReearthAccounts(cfg *ServerConfig) echo.MiddlewareFunc {
	return func(next echo.HandlerFunc) echo.HandlerFunc {
		return func(c echo.Context) error {
			req := c.Request()
			ctx := req.Context()

			ctx = adapter.AttachCurrentHost(ctx, cfg.Config.Host)

			// Skip authentication for signup endpoints
			if req.URL.Path == "/api/signup" {
				log.Debugfc(ctx, "auth: skipping authentication for signup endpoint")
				c.SetRequest(req.WithContext(ctx))
				return next(c)
			}

			// The token is set as is and sent to reearth-accounts for verification.
			token := strings.TrimPrefix(req.Header.Get("Authorization"), "Bearer ")
			ctx = adapter.AttachJwtToken(ctx, token)

			var u *accountsUser.User

			// debug mode
			if cfg.Debug {

				if userID := req.Header.Get("X-Reearth-Debug-User"); userID != "" {

					userModel, err := cfg.AccountsAPIClient.UserRepo.FindByID(ctx, userID)
					if err != nil {
						return handleAccountsAPIError(ctx, fmt.Errorf("(FindByID): %w, %s", err, userID))
					}

					if userModel != nil {
						u, err = buildAccountDomainUserFromUserModel(ctx, userModel)
						if err != nil {
							log.Errorfc(ctx, "accounts API: failed to build user in debug mode: %v", err)
							return echo.NewHTTPError(http.StatusInternalServerError, err.Error())
						}
					}

				}

			}

			if u == nil {

				userModel, err := cfg.AccountsAPIClient.UserRepo.FindMe(ctx)
				if err != nil {
					return handleAccountsAPIError(ctx, fmt.Errorf("(FindMe): %w, %s", err, req.URL.Path))
				}

				if userModel != nil {
					u, err = buildAccountDomainUserFromUserModel(ctx, userModel)
					if err != nil {
						log.Errorfc(ctx, "accounts API: failed to build user: %v", err)
						return echo.NewHTTPError(http.StatusInternalServerError, err.Error())
					}
				}

			}

			if u != nil {
				ctx = adapter.AttachUser(ctx, u)
				log.Debugfc(ctx, "auth: user: id=%s name=%s email=%s", u.ID(), u.Name(), u.Email())

				op, err := generateOperator(ctx, cfg, u)
				if err != nil {
					return err
				}

				ctx = adapter.AttachOperator(ctx, op)
				log.Debugfc(ctx, "auth: op: %#v", op)

			} else {
				log.Errorfc(ctx, "User information not found: %s", req.URL.Path)
			}

			c.SetRequest(req.WithContext(ctx))
			return next(c)
		}
	}
}

func handleAccountsAPIError(ctx context.Context, err error) error {
	if accountsGqlError.IsUnauthorized(err) {
		log.Warnfc(ctx, "accounts API: unauthorized: %s", err.Error())
		return echo.NewHTTPError(http.StatusUnauthorized, "unauthorized")
	}

	if errors.Is(err, rerror.ErrNotFound) {
		log.Warnfc(ctx, "accounts API: user not found: %s", err.Error())
		return echo.NewHTTPError(http.StatusNotFound, "user not found")
	}

	log.Errorfc(ctx, "accounts API: failed to fetch user: %s", err.Error())
	return echo.NewHTTPError(http.StatusInternalServerError, "failed to fetch user from accounts API")
}

func buildAccountDomainUserFromUserModel(ctx context.Context, userModel *accountsUser.User) (*accountsUser.User, error) {
	uId, _ := accountsUser.IDFrom(userModel.ID().String())
	wid, _ := accountsWorkspace.IDFrom(userModel.Workspace().String())

	usermetadata := accountsUser.MetadataFrom(
		userModel.Metadata().PhotoURL(),
		userModel.Metadata().Description(),
		userModel.Metadata().Website(),
		userModel.Metadata().Lang(),
		accountsUser.Theme(userModel.Metadata().Theme()),
	)

	// Convert auths to user.Auth slice
	auths := make([]accountsUser.Auth, 0, len(userModel.Auths()))
	for _, authStr := range userModel.Auths() {
		auths = append(auths, accountsUser.AuthFrom(authStr.String()))
	}

	u, err := accountsUser.New().
		ID(uId).
		Name(userModel.Name()).
		Alias(userModel.Alias()).
		Email(userModel.Email()).
		Metadata(usermetadata).
		Workspace(wid).
		Auths(auths).
		Build()

	if err != nil {
		log.Errorfc(ctx, "accounts API: failed to build user: %v", err)
		return nil, err
	}

	return u, nil
}

func generateOperator(ctx context.Context, cfg *ServerConfig, u *accountsUser.User) (*usecase.Operator, error) {
	if u == nil {
		return nil, nil
	}

	uid := u.ID()

	var workspaces accountsWorkspace.List
	var err error
	// TODO: Internal API behavior has not been fully considered yet.
	// Skip the accounts API when there is no JWT in context (e.g. Pub/Sub-triggered
	// endpoints like /api/storage-event) and fall back to the local repo directly.
	if cfg.AccountsAPIClient != nil && !cfg.Config.Visualizer.InternalApi.Active && adapter.JwtToken(ctx) != "" {
		workspaces, err = cfg.AccountsAPIClient.WorkspaceRepo.FindByUser(ctx, uid.String())
	} else {
		workspaces, err = cfg.Repos.Workspace.FindByUser(ctx, uid)
	}

	if err != nil {
		log.Errorfc(ctx, "auth: failed to fetch workspaces: %v", err)
		return nil, err
	}

	wsList := accountsWorkspace.List(workspaces)

	scenes, err := cfg.Repos.Scene.FindByWorkspace(ctx, wsList.IDs()...)
	if err != nil {
		return nil, err
	}

	readableWorkspaces := wsList.FilterByUserRole(uid, accountsRole.RoleReader).IDs()
	writableWorkspaces := wsList.FilterByUserRole(uid, accountsRole.RoleWriter).IDs()
	maintainingWorkspaces := wsList.FilterByUserRole(uid, accountsRole.RoleMaintainer).IDs()
	owningWorkspaces := wsList.FilterByUserRole(uid, accountsRole.RoleOwner).IDs()

	return &usecase.Operator{
		AcOperator: &accountsWorkspace.Operator{
			User:                   &uid,
			ReadableWorkspaces:     readableWorkspaces,
			WritableWorkspaces:     writableWorkspaces,
			MaintainableWorkspaces: maintainingWorkspaces,
			OwningWorkspaces:       owningWorkspaces,
		},
		ReadableScenes:    scenes.FilterByWorkspace(readableWorkspaces...).IDs(),
		WritableScenes:    scenes.FilterByWorkspace(writableWorkspaces...).IDs(),
		MaintainingScenes: scenes.FilterByWorkspace(maintainingWorkspaces...).IDs(),
		OwningScenes:      scenes.FilterByWorkspace(owningWorkspaces...).IDs(),
	}, nil
}

func AuthRequiredMiddleware() echo.MiddlewareFunc {
	return func(next echo.HandlerFunc) echo.HandlerFunc {
		return func(c echo.Context) error {
			ctx := c.Request().Context()
			if adapter.Operator(ctx) == nil {
				return echo.ErrUnauthorized
			}
			return next(c)
		}
	}
}
