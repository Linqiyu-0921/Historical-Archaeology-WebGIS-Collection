package mongodoc

import (
	"time"

	accountsID "github.com/reearth/reearth-accounts/server/pkg/id"
	"github.com/reearth/reearth/server/pkg/id"
	"github.com/reearth/reearth/server/pkg/project"
	"golang.org/x/exp/slices"
)

type ProjectMetadataDocument struct {
	ID              string
	Workspace       string
	Project         string
	ImportStatus    *string
	ImportResultLog *map[string]any
	Readme          *string
	License         *string
	Topics          *[]string
	StarCount       *int64
	StarredBy       *[]string
	CreatedAt       *time.Time
	UpdatedAt       *time.Time
}

type ProjectMetadataConsumer = Consumer[*ProjectMetadataDocument, *project.ProjectMetadata]

func NewProjectMetadataConsumer(workspaces []accountsID.WorkspaceID) *ProjectMetadataConsumer {
	return NewConsumer[*ProjectMetadataDocument, *project.ProjectMetadata](func(s *project.ProjectMetadata) bool {
		return workspaces == nil || slices.Contains(workspaces, s.Workspace())
	})
}

func NewProjectMetadata(r *project.ProjectMetadata) (*ProjectMetadataDocument, string) {
	rid := r.ID().String()

	var importStatus *string
	if r.ImportStatus() != nil {
		v := string(*r.ImportStatus())
		importStatus = &v
	}

	return &ProjectMetadataDocument{
		ID:              rid,
		Workspace:       r.Workspace().String(),
		Project:         r.Project().String(),
		ImportStatus:    importStatus,
		ImportResultLog: r.ImportResultLog(),
		Readme:          r.Readme(),
		License:         r.License(),
		Topics:          r.Topics(),
		StarCount:       r.StarCount(),
		StarredBy:       r.StarredBy(),
		CreatedAt:       r.CreatedAt(),
		UpdatedAt:       r.UpdatedAt(),
	}, rid

}

func (d *ProjectMetadataDocument) Model() (*project.ProjectMetadata, error) {
	rid, err := id.ProjectMetadataIDFrom(d.ID)
	if err != nil {
		return nil, err
	}

	wid, err := accountsID.WorkspaceIDFrom(d.Workspace)
	if err != nil {
		return nil, err
	}

	pid, err := id.ProjectIDFrom(d.Project)
	if err != nil {
		return nil, err
	}

	var importStatus *project.ProjectImportStatus
	if d.ImportStatus != nil {
		v := project.ProjectImportStatus(*d.ImportStatus)
		importStatus = &v
	}

	builder := project.NewProjectMetadata().
		ID(rid).
		Workspace(wid).
		Project(pid).
		ImportStatus(importStatus).
		ImportResultLog(d.ImportResultLog).
		Readme(d.Readme).
		License(d.License).
		Topics(d.Topics).
		StarCount(d.StarCount).
		StarredBy(d.StarredBy).
		UpdatedAt(d.UpdatedAt).
		CreatedAt(d.CreatedAt)

	return builder.Build()
}
