package gql

import (
	"context"

	accountsID "github.com/reearth/reearth-accounts/server/pkg/id"
	"github.com/reearth/reearth/server/internal/adapter/gql/gqldataloader"
	"github.com/reearth/reearth/server/internal/adapter/gql/gqlmodel"
	"github.com/reearth/reearth/server/internal/usecase/interfaces"

	"github.com/reearth/reearth-accounts/server/pkg/gqlclient"
	"github.com/reearth/reearthx/util"
)

type WorkspaceLoader struct {
	client  *gqlclient.Client
	usecase interfaces.Workspace
}

func NewWorkspaceLoader(client *gqlclient.Client, usecase interfaces.Workspace) *WorkspaceLoader {
	return &WorkspaceLoader{client: client, usecase: usecase}
}

func (c *WorkspaceLoader) Fetch(ctx context.Context, ids []gqlmodel.ID) ([]*gqlmodel.Workspace, []error) {
	uids, err := util.TryMap(ids, gqlmodel.ToID[accountsID.Workspace])
	if err != nil {
		return nil, []error{err}
	}

	if c.client != nil {
		workspaces := make([]*gqlmodel.Workspace, 0, len(uids))
		for _, uid := range uids {
			w, err := c.client.WorkspaceRepo.FindByID(ctx, uid.String())
			if err != nil {
				return nil, []error{err}
			}
			workspaces = append(workspaces, gqlmodel.ToWorkspace(w))
		}
		return workspaces, nil
	}

	res, err := c.usecase.Fetch(ctx, uids, getAcOperator(ctx))
	if err != nil {
		return nil, []error{err}
	}
	workspaces := make([]*gqlmodel.Workspace, 0, len(res))
	for _, t := range res {
		workspaces = append(workspaces, gqlmodel.ToWorkspace(t))
	}
	return workspaces, nil
}

func (c *WorkspaceLoader) FindByUser(ctx context.Context, uid gqlmodel.ID) ([]*gqlmodel.Workspace, error) {
	userid, err := gqlmodel.ToID[accountsID.User](uid)
	if err != nil {
		return nil, err
	}

	if c.client != nil {
		res, err := c.client.WorkspaceRepo.FindByUser(ctx, userid.String())
		if err != nil {
			return nil, err
		}
		workspaces := make([]*gqlmodel.Workspace, 0, len(res))
		for _, w := range res {
			workspaces = append(workspaces, gqlmodel.ToWorkspace(w))
		}
		return workspaces, nil
	}

	res, err := c.usecase.FindByUser(ctx, userid, getAcOperator(ctx))
	if err != nil {
		return nil, err
	}
	workspaces := make([]*gqlmodel.Workspace, 0, len(res))
	for _, t := range res {
		workspaces = append(workspaces, gqlmodel.ToWorkspace(t))
	}
	return workspaces, nil
}

// data loader

type WorkspaceDataLoader interface {
	Load(gqlmodel.ID) (*gqlmodel.Workspace, error)
	LoadAll([]gqlmodel.ID) ([]*gqlmodel.Workspace, []error)
}

func (c *WorkspaceLoader) DataLoader(ctx context.Context) WorkspaceDataLoader {
	return gqldataloader.NewWorkspaceLoader(gqldataloader.WorkspaceLoaderConfig{
		Wait:     dataLoaderWait,
		MaxBatch: dataLoaderMaxBatch,
		Fetch: func(keys []gqlmodel.ID) ([]*gqlmodel.Workspace, []error) {
			return c.Fetch(ctx, keys)
		},
	})
}

func (c *WorkspaceLoader) OrdinaryDataLoader(ctx context.Context) WorkspaceDataLoader {
	return &ordinaryWorkspaceLoader{
		fetch: func(keys []gqlmodel.ID) ([]*gqlmodel.Workspace, []error) {
			return c.Fetch(ctx, keys)
		},
	}
}

type ordinaryWorkspaceLoader struct {
	fetch func(keys []gqlmodel.ID) ([]*gqlmodel.Workspace, []error)
}

func (l *ordinaryWorkspaceLoader) Load(key gqlmodel.ID) (*gqlmodel.Workspace, error) {
	res, errs := l.fetch([]gqlmodel.ID{key})
	if len(errs) > 0 {
		return nil, errs[0]
	}
	if len(res) > 0 {
		return res[0], nil
	}
	return nil, nil
}

func (l *ordinaryWorkspaceLoader) LoadAll(keys []gqlmodel.ID) ([]*gqlmodel.Workspace, []error) {
	return l.fetch(keys)
}
